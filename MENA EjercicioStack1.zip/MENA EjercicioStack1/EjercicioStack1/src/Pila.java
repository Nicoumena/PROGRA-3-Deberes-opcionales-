import java.util.Stack;

public class Pila {
    private Stack<String> coleccion;
    private static final int LIMITE = 10;

    public Pila(){
        coleccion=new Stack<String>();
    }

    public void insertar(String dato) throws Exception {
        if (coleccion.size()>=LIMITE){
            throw new Exception("La pila ha alcanzado el límite de 10 elementos");
        }
        coleccion.push(dato);
    }
    public boolean estaVacia() {
        return coleccion.isEmpty();
    }
    public String extraer() throws Exception {
        if (estaVacia()) {
            throw new Exception("Pila está vacía");
        }
        return coleccion.pop();
    }

    public String cima(){
        return coleccion.peek();
    }

    @Override
    public String toString() {
        StringBuilder lista=new StringBuilder();
        for(int i=coleccion.size()-1; i>=0; i--){
            lista.append(coleccion.get(i)+"\n");
        }
        return lista.toString();
    }
}
