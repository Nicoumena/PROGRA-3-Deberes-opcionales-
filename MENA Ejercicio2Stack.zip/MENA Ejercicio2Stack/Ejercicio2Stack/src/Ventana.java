import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel principal;
    private JTextArea txtCodigo;
    private JButton btnComprobar;
    private JLabel lblCodigo;
    private JTextArea txtPila; // NUEVO: área para mostrar pila

    public Ventana() {
        btnComprobar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    Pila pilas = new Pila();
                    String codigo = txtCodigo.getText();
                    txtPila.setText(""); // Limpiar vista de pila

                    for (int i = 0; i <= codigo.length() - 1; i++) {
                        char c = codigo.charAt(i);
                        if (c == '(' || c == '{' || c == '[') {
                            pilas.insertar(String.valueOf(c));
                            JOptionPane.showMessageDialog(null, "Se insertó: " + c);
                            txtPila.setText(pilas.toString());
                        } else if (c == ')' || c == '}' || c == ']') {
                            try {
                                char salida = pilas.extraer().charAt(0);
                                JOptionPane.showMessageDialog(null, "Se extrajo: " + salida);
                                txtPila.setText(pilas.toString());

                                if ((c == ')' && salida != '(') ||
                                        (c == '}' && salida != '{') ||
                                        (c == ']' && salida != '[')) {
                                    JOptionPane.showMessageDialog(null, "Código no balanceado");
                                    return;
                                }
                            } catch (Exception ex) {
                                JOptionPane.showMessageDialog(null, "Código no balanceado: " + ex.getMessage());
                                return;
                            }
                        }
                    }

                    if (pilas.esVacia())
                        JOptionPane.showMessageDialog(null, "Código balanceado");
                    else
                        JOptionPane.showMessageDialog(null, "Código no balanceado");

                    txtPila.setText(pilas.toString());

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
