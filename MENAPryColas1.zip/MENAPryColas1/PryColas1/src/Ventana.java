import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel principal;
    private JComboBox cboModelo;
    private JTextField txtAnio;
    private JButton btnAgregar;
    private JButton btnDesencolar;
    private JTextArea txtListarAutos;
    private JLabel lblMensaje;
    private ColaAutos listaAutos=new ColaAutos();

    public Ventana() {
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String modelo = cboModelo.getSelectedItem().toString();
                    String añoText = txtAnio.getText();

                    if (añoText.isEmpty()) {
                        throw new Exception("Por favor ingrese el año del auto");
                    }

                    int anio = Integer.parseInt(añoText);


                    if (anio > 2025) {
                        JOptionPane.showMessageDialog(null, "El año no puede ser mayor a 2025");
                        return;
                    }


                    if (anio < 0) {
                        JOptionPane.showMessageDialog(null, "El año no puede ser negativo");
                        return;
                    }


                    listaAutos.encolar(new Auto(modelo, anio));
                    txtListarAutos.setText(listaAutos.listarAutos());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });
        btnDesencolar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Auto autox = listaAutos.desencolar();
                    txtListarAutos.setText(listaAutos.listarAutos());
                    
                    int añoActualMasUno = 2026;
                    int antiguedad = añoActualMasUno - autox.getAnio();
                    int monto = antiguedad * 50;

                    lblMensaje.setText("Auto atendido " + autox + " debe pagar $" + monto);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame.pack();
        frame.setSize(600,400);
        frame.setVisible(true);
    }
}
