import javax.swing.*;

public class ventana {
    private JPanel Principal;
    private JTextField txtIdentificador;
    private JTextField txtTarea;
    private JTextField txtPresupuesto;
    private JComboBox cboPrioridad;
    private JButton btnAgregar;
    private JTextArea txtListarTareas;
    private JComboBox cboCategoria;
    private JTextArea txtListaPresupuesto;
    private JComboBox cboPCategoria;
    private JTextArea txtPresupuestoCatego;
}
